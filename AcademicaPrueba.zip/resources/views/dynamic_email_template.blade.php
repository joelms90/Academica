<p>Mis tareas pendientes: <br>
	@foreach($data as $dat)
	{{$dat->description}}<br>
	@endforeach <p>
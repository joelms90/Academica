@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">


		<h1 class="display-4 mt-5">Mensaje Enviado a tu correo</h1>

    </div>
</div>
@endsection

<h2>Nombre Tarea: </h2>
<p><?php echo e($task->description); ?></p>
<p><?php echo e($task->status); ?></p>

<h3>Tarea Asiganada a:</h3>

<ul>
    <?php $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($user->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\laragon\www\AcademicaPrueba\resources\views/show.blade.php ENDPATH**/ ?>
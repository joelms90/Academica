<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">

		  <table class="table table-striped">
		  <thead class="text-center">
		    <tr class="text-center">
		      <th scope="col">Descripción</th>
		      <th scope="col">Status</th>
		      <th scope="col">Encargados</th>
		    
		    </tr>
		  </thead>
		  <tbody class="text-center">
		  	<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr class="text-center">
		      <th scope="row"><?php echo e($task->description); ?></th>
		      <td><?php echo e($task->status); ?></td>
		      <td>
		      <?php $__currentLoopData = $task->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      <a><?php echo e($user->name); ?> Teléfono: <?php echo e($user->phone); ?> Correo:<?php echo e($user->email); ?></a><br>
		      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		      <td>
		     
		    
		    </tr>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		  </tbody>
		</table>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AcademicaPrueba\resources\views/show.blade.php ENDPATH**/ ?>
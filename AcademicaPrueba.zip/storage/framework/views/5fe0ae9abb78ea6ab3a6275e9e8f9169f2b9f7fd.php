<p>Mis tareas pendientes 
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($dat->description); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <p><?php /**PATH C:\laragon\www\AcademicaPrueba\resources\views/dynamic_email_template.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">


		<h1 class="display-4 mt-5">Mensaje Enviado a tu correo</h1>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AcademicaPrueba\resources\views/sent.blade.php ENDPATH**/ ?>
<h2>Usuario: </h2>
<p><?php echo e($user->name); ?></p>

<h3>Tareas:</h3>

<ul>
    <?php $__currentLoopData = $user->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($task->description); ?> || <?php echo e($task->status); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\laragon\www\AcademicaPrueba\resources\views/show2.blade.php ENDPATH**/ ?>
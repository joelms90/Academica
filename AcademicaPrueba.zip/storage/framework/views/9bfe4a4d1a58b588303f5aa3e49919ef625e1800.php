<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">



            <div id="app">
   <tasks-list  v-bind:current-user='<?php echo Auth::user()->toJson(); ?>'></tasks-list>

</div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\AcademicaPrueba\resources\views/home.blade.php ENDPATH**/ ?>